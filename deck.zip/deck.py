# ---------------------
# Name: Zi Xue Lim
# ID:1573849
# CMPT274, Fall 2019
# Excercise deck of cards
# ---------------------
import sys
import copy
class Deck:
	def __init__(self, cards):
		self.__deck = copy.copy(cards)  # shallow copy
		self.__deck = [y.strip() and y.upper() for y in self.__deck]  # make deck all upper case and remove whitespaces
		if self.__deck[len(self.__deck)-1] == "":  # sometimes when reading certain text files an empty variable is sometimes assigned to the last position in list so need to delete
			del self.__deck[len(self.__deck)-1]
	def deal(self):
		if self.__deck	== []:
			topCard = "empty"  # tell game to stop if no more cards
		else:
			topCard = self.__deck[0]  # assign top card
			del self.__deck[0]  # delete the top card
		return topCard       
		pass    
	def validate(self):
		typeCard = ["2","3","4","5","6","7","8","9","T","K","Q","J","A"]  # ranks xof card
		groupCard = ["S","H","C","D"]  # suite of card
		wrong = ""
		count = 0
		countCard = 0
		valid = True
		deckReapeat = {}
		while valid == True and count < len(self.__deck):  # while loop to make sure valid cards if the rank is in the rank list and the suit is in the suit list above
			card = list(self.__deck[count])
			if card [0] not in typeCard:
				valid = False
				wrong = "Card " + self.__deck[count] + " is not a valid card"
			else:
				if card [1] not in groupCard:
					valid = False
					wrong = "Card " + self.__deck[count] + " is not a valid card"
			count = count +1
		if not len(self.__deck) == 52 and valid == True:  # first check if there are 52 cards in the deck
			wrong = "Incomplete deck, applies when there are less than 52 valid cards in the deck"
			valid = False
		else:  # check if there any repeats in the deck
			while countCard <52 and valid == True:
				if self.__deck[countCard] not in deckReapeat:
					deckReapeat[self.__deck[countCard]] = 1
				else:
					valid = False
					wrong = "Deck contains duplicate cards"
				countCard +=1
		return valid, wrong # return true and false and if false a reason, if true empty for wrong
	def __str__(self):
		serperator = "-"
		return serperator.join(self.__deck)
	pass
def convertToInt(cardsGame):  # convert to numerical value so easier to compare
	if cardsGame == "T":
		cardsGame = 10
	elif cardsGame == "J":
		cardsGame = 11
	elif cardsGame == "Q":
		cardsGame = 12
	elif cardsGame == "K":
		cardsGame = 13
	elif cardsGame == "A":
		cardsGame = 14
	else:
		cardsGame = int(cardsGame)
	return cardsGame
def playGame(newDeck):
	endGame = False
	i = 0
	while endGame == False:
			playerCard = list(newDeck.deal())
			if playerCard == ['e', 'm', 'p', 't', 'y']:  # if list of self.__deck is empty will return "empty" and since playerCard convert to list, when game ends it will be in a list
				endGame = True
			else:
				dealerCard = list(newDeck.deal())
				playRank = convertToInt(playerCard[0])
				dealRank = convertToInt(dealerCard[0])
				if playRank > dealRank:  # compare who has the higher rank or tie
					print("Round " + str(i+1) + ": Player wins!")
				elif dealRank > playRank:
					print("Round " + str(i+1) + ": Dealer wins!")
				else:
					print("Round " + str(i+1) + ": Tie!")
			i += 1
if __name__ =="__main__":
	file = open(sys.argv[1] , "r").read().split('\n')  #splits the file into list based on the lines
	newDeck = Deck(file)  # assign newDeck to deck class
	validList = newDeck.validate()
	print(validList[1])
	if validList[0] == True:  # only plays game if deck of cards is valid
		playGame(newDeck)